package com.example.avunid2;

import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class ShowTrails extends AppCompatActivity {
    TextView traildetail;
    TrilhasDB trilhadb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_show_trails);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        traildetail = findViewById(R.id.trailDetail);
        trilhadb = new TrilhasDB(this);
        displayWaypoints();
    }

    private void displayWaypoints() {
        ArrayList<Waypoint> waypoints = trilhadb.recuperarWaypoints();
        StringBuilder log = new StringBuilder();
        for (int i = 0; i < waypoints.size(); i++) {
            log.append("(").append(i + 1).append(")").append(waypoints.get(i).getLatitude()).append(", ").append(waypoints.get(i).getLongitude()).append("\n");
        }
        traildetail.setText(log.toString());
    }
}