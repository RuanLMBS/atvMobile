package com.example.avunid2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Application extends AppCompatActivity {
    Button getTrailbtn;
    Button showTrailbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_application);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        getTrailbtn = findViewById(R.id.getTrailbtn);
        showTrailbtn = findViewById(R.id.showTrailbtn);
        onClick(getTrailbtn);
        onClick(showTrailbtn);
    }

    public void onClick(Button btn) {
        if(btn==getTrailbtn) {
            btn.setOnClickListener(v->{
                Intent intent = new Intent(this, TrailActivity.class);
                startActivity(intent);
            });

        }

        if(btn==showTrailbtn) {
            btn.setOnClickListener(v->{
                Intent intent = new Intent(this, ShowTrails.class);
                startActivity(intent);
            });

        }
    }
}