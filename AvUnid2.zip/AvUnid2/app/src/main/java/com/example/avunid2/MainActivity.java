package com.example.avunid2;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    SQLiteDatabase db;
    Button gmbtn;
    Button appbtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        gmbtn = findViewById(R.id.gmbtn);
        appbtn = findViewById(R.id.appbtn);
        onClick(gmbtn);
        onClick(appbtn);
        String dbPath="data/data/com.example.SQLITEAPP/MeuBanco.db";

        try {
            db = SQLiteDatabase.openDatabase(dbPath,
                    null,SQLiteDatabase.CREATE_IF_NECESSARY);
        // Faça algo com o banco...

        // Feche o banco
            db.close();
        }
        catch (SQLiteException e) {

            System.out.println(e.getMessage());

        }
    }

    public void onClick(Button btn) {
        if(btn==gmbtn) {
            btn.setOnClickListener(v->{
                Intent intent = new Intent(this, MapsActivity.class);
                startActivity(intent);
            });

        }

        if(btn==appbtn) {
            btn.setOnClickListener(v->{
                Intent intent = new Intent(this, Application.class);
                startActivity(intent);
            });

        }
    }


}