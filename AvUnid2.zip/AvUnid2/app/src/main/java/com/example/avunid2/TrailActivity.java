package com.example.avunid2;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;


import java.util.ArrayList;

public class TrailActivity extends AppCompatActivity {

    Button startbtn;
    Button stopbtn;
    TextView textid;

    private static final int REQUEST_LOCATION_UPDATES=1;

    private FusedLocationProviderClient mFusedLocationProviderClient;
    private LocationRequest mLocationRequest;
    private LocationCallback mLocationCallback;

    TrilhasDB trilhadb;
    int waypoint_counter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_trail);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        startbtn = findViewById(R.id.startbtn);
        stopbtn = findViewById(R.id.stopbutton);
        textid = findViewById(R.id.textid);
        onClick(startbtn);
        onClick(stopbtn);

    }

    public void onClick(Button btn) {
        if(btn==startbtn) {
            btn.setOnClickListener(v->{
                trilhadb=new TrilhasDB(TrailActivity.this);
                trilhadb.apagarTrilha();
                startLocationUpdates();
            });

        }

        if(btn==stopbtn) {
            btn.setOnClickListener(v->{
                stopLocationUpdates();
                trilhadb.close();

            });

        }
    }

    public void startLocationUpdates() {
        // 2. Verifica a permissão para obtenção da localização
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED) {
            // A permissão foi dada– OK vá em frente
            // 3. Cria o cliente (FusedLocationProviderClient)
            mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
            // 4. Configura a solicitação de localizações (LocationRequest)

            mLocationRequest = new LocationRequest.Builder(5*1000).build();

            // 5. Programa o escutador para consumir as novas localizações geradas (LocationCallback)
            mLocationCallback = new LocationCallback() {
                @Override
                public void onLocationResult(LocationResult locationResult) {
                    super.onLocationResult(locationResult);
                    Location location=locationResult.getLastLocation();
                    addWayPoint(location);
                } };
            // 6. Manda o cliente começar a gerar atualizações de localização.
            mFusedLocationProviderClient.requestLocationUpdates(mLocationRequest,mLocationCallback,null);
         ;

        } else {
            // A permissão ainda não foi dada - Solicite a permissão
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    REQUEST_LOCATION_UPDATES);
        }
    }

        public void addWayPoint(Location location) {
            Waypoint waypoint = new Waypoint(location);
            trilhadb.registrarWaypoint(waypoint);
            waypoint_counter++;
            textid.setText("Adicionado(" + waypoint_counter + "):" + waypoint.getLatitude()+ " "+waypoint.getLongitude());

        }

    public void stopLocationUpdates() {
        if (mFusedLocationProviderClient != null) {
            mFusedLocationProviderClient.removeLocationUpdates(mLocationCallback);
        }
        ArrayList<Waypoint> waypoints=trilhadb.recuperarWaypoints();
        String log="";
        for (int i=0;i<waypoints.size();i++){
            log+="("+(i+1)+")"+waypoints.get(i).getLatitude()+", "+waypoints.get(i).getLongitude()+"\n";
        }
        textid.setText(log);
    }

}